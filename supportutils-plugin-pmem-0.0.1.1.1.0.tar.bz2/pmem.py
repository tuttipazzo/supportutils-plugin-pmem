#!/usr/bin/python3
# Plugin for suse supportconfig support tool.
#
# This copyrighted material is made available to anyone wishing to use,
# modify, copy, or redistribute it subject to the terms and conditions of
# version 2 of the GNU General Public License.
#
# See the LICENSE file in the source distribution for further information.

import os
import subprocess
import sys
from pathlib import Path

# to run
#   LOG=/tmp python3 pmem.py

COMMAND_HDR = "#==[ Command ]======================================#\n"
CFG_HDR = "#==[ Configuration File ]===========================#\n"
LOG_HDR = "#==[ Log File ]=====================================#\n"
NOTE_HDR = "#==[ Note ]=========================================#\n"
SUMMARY_HDR = "#==[ Summary ]======================================#\n"
ENTRY_HDR = "#==[ Entry ]========================================#\n"
ERROR_HDR = "#==[ ERROR ]========================================#\n"

BINARY_ATTR = ['ndctl', 'daxctl']
PKGS = ['ndctl', 'libndctl6', 'ipmctl']
SERVICE = ['ndctl-monitor']

CFG = [
    "/etc/ndctl",
    "/etc/ipmctl.conf",
    "/etc/ndctl/monitor.conf",
    "/var/log/ipmctl",
    "/var/log/ndctl/"
]

CMDS = [
    ['ndctl', '--version'],
    ['ndctl', 'list', '-vvv'],
    ['ndctl', 'list', '-iBDFHMNRX'],
    ['ndctl', 'read-labels', '-j', 'all'],
    ['daxctl', 'list'],
    ['daxctl', 'list', '-iDR'],
    ['ipmctl', 'version'],
    ['ipmctl', 'show', '-cap'],
    ['ipmctl', 'show', '-cel'],
    ['ipmctl', 'show', '-dimm'],
    ['ipmctl', 'show', '-a', '-dimm'],
    ['ipmctl', 'show', '-dimm', '-pcd'],
    ['ipmctl', 'show', '-dimm', '-performance'],
    ['ipmctl', 'show', '-error', 'Thermal', '-dimm'],
    ['ipmctl', 'show', '-error', 'Media', '-dimm'],
    ['ipmctl', 'show', '-firmware'],
    ['ipmctl', 'show', '-goal'],
    ['ipmctl', 'show', '-memoryresources'],
    ['ipmctl', 'show', '-performance'],
    ['ipmctl', 'show', '-preferences'],
    ['ipmctl', 'show', '-region'],
    ['ipmctl', 'show', '-sensor'],
    ['ipmctl', 'show', '-a', '-sensor'],
    ['ipmctl', 'show', '-socket'],
    ['ipmctl', 'show', '-system'],
    ['ipmctl', 'show', '-system', '-capabilities'],
    ['ipmctl', 'show', '-a', '-system', '-capabilities'],
    ['ipmctl', 'show', '-topology'],
    ['ipmctl', 'show', '-a', '-topology']
]

def log_error(logfile, msg):
    logfile.write(ERROR_HDR)
    logfile.write("%s\n" % msg)
    logfile.write("\n")

def log_config(logfile, msgs):
    logfile.write(CFG_HDR)
    # don't save empty or comment lines
    for msg in msgs:
        if len(msg) != 0 and not msg.startswith('#'):
            logfile.write("%s\n" % msg)
    logfile.write("\n")

def run_cmd(cmd, check, shell=False):
    output = subprocess.run(
        cmd,
        check=check,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        shell=shell
    )
    return output.stdout.decode('UTF-8')

def log_cmd(logfile: object, cmd: object, check: object = True, shell: object = False) -> object:
    logfile.write(COMMAND_HDR)
    logfile.write("%s\n" % " ".join(cmd))
    status = True
    try:
        if shell:
            cmd = " ".join(cmd)
            output = run_cmd(cmd, check, shell)
        else:
            output = run_cmd(cmd, check, shell)
        logfile.write(output)
    except Exception as e:
        # logfile.write("ERROR: subprocess raised error: {}\n".format(e))
        status = False
    logfile.write("\n")
    return status

def rpm_verify(logfile):
    # If there are changes this gives a 1 returncode, but we don't care.
    for p in PKGS:
        log_cmd(logfile, ["rpm", "-V", p], check=False)

def service_check(logfile, inst_name):
    log_cmd(logfile, ["systemctl", "status", inst_name], check=False)
    log_cmd(logfile, ["ls", "-alhH",
                      "/etc/systemd/system/{0}.service.d".format(inst_name)], check=False)
    try:
        # Can we display the content of this dir?
        if os.path.exists("/etc/systemd/system/{0}.service.d".format(inst_name)):
            for cnf in os.listdir("/etc/systemd/system/{0}.service.d".format(inst_name)):
                p = os.path.join("/etc/systemd/system/{0}.service.d".format(inst_name), cnf)
                dump_log_config(logfile, p)
    except Exception as e:
        # Probably no overrides.
        log_error(logfile, e)

def service_check_logs(logfile, inst_name):
    log_cmd(logfile, ["journalctl", "-u", inst_name, "-p", "5"], check=False)

def dump_log_config(logfile, path):
    if os.path.exists(path):
        with open(path, 'r') as cnf_f:
            log_config(logfile, ["config -> {0} :".format(path)] + [x.replace('\n', '') for x in cnf_f.readlines()])
    else:
        log_error(logfile, "No such configfile: {0}".format(path))


def dump_log_config_traverse(logfile, path):
    if os.path.exists(path):
        if os.path.isdir(path):
            for file in path.iterdir():
                if file.is_dir():
                    dump_log_config_traverse(logfile, file)
                else:
                    dump_log_config(logfile, file)
    else:
        log_error(logfile, "No such configfile: {0}".format(path))

def run_cmds(logfile, check=True, shell=False):
    for c in CMDS:
        log_cmd(logfile, c, check, shell)

def do_supportconfig():
    # Get our logfile name
    logfilename = os.path.join(os.environ['LOG'], 'pmem.txt')
    # Start to write some stuff out.
    with open(logfilename, 'w') as logfile:
        if not log_cmd(logfile, ["rpm", "-q", PKGS[0]]):
            logfile.close()
            os.remove(logfilename)
            sys.exit(0)

        # Do the rpm verification to proceed
        rpm_verify(logfile)
        # Display all .dsrc files from root home or container if present.
        for p in CFG:
            if os.path.isdir(p):
                myPath = Path(p)
                dump_log_config_traverse(logfile, myPath)
            else:
                dump_log_config(logfile, p)

        for s in SERVICE:
            service_check(logfile, s)
            service_check_logs(logfile, s)
        # We know that we can proceed now with lib389, because it imported correctly.
        run_cmds(logfile)

if __name__ == "__main__":
    do_supportconfig()

# vim: set et ts=4 sw=4 :
